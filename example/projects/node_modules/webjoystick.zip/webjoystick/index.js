module.exports = require('./lib/webjoystick');
